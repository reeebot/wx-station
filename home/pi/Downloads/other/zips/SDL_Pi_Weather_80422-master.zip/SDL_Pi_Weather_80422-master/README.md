SDL_Weather_80422 - Python Class Library for:

 SwitchDoc Labs WeatherRack 
 Argent Data Systems 
 SparkFun Weather Station 

Created by SwitchDoc Labs February 13, 2015. Released into the public domain.

www.switchdoc.com

Version 1.0 - February 13, 2015
Version 1.1 - February 20, 2015 - Added 3.3V Constants
Version 1.2 - March 30, 2015 - Fixed Wind Gust Measurement 
Version 1.3 - July 25, 2015 - Removed 300ms debounce error
Version 1.4 - August 13, 2015 - Removed divide by 2 in rain measurements (see 1.3)
Version 1.5 - November 29, 2015 - change ADS1015 address to the default 0x48 (which is the default on WeatherPiArduino) 



