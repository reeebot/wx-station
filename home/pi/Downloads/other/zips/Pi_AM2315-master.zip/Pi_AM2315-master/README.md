Python Test Programs for AM2315 Temperature Sensors
SwitchDoc Labs 7/2015


Other installations required for AM2315:

sudo apt-get install python-pip 
sudo apt-get install libi2c-dev 
sudo pip install tentacle_pi

testAM2315.py - test program for AM2315
