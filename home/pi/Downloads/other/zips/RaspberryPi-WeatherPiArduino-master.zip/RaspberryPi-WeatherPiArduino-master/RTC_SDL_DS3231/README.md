
Raspberry Pi Python Library for SwitchDoc Labs DS3231/AT24C32 RTC Module

SwitchDoc Labs, LLC  December 19, 2014

Clone respository and run testDS3231.py to test

More Information on www.switchdoc.com

Runs RTC and EEPROM


