SDL_Weather_80422 - Python Class Library for:

 SwitchDoc Labs WeatherRack 
 Argent Data Systems 
 SparkFun Weather Station 

Created by SwitchDoc Labs February 13, 2015. Released into the public domain.

www.switchdoc.com


Version 1.0 - February 13, 2015
