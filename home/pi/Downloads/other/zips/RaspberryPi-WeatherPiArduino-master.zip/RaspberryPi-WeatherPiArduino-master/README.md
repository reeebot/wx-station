WeatherPiArduino Libraries and Example for Raspberry Pi

Supports SwitchDoc Labs WeatherRack / Argent Data / Sparkfun

Version 1.2 

SwitchDocLabs Documentation for WeatherPiArduino under products on:

http://www.switchdoc.com/

March 28, 2015 - added subdirectories

Support for all 7 I2C devices supported by WeatherPiArduino

