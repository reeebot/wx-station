# raspberrypi-weather-station
Weather Sensor/program for the Raspberry Pi B+

More detailed notes at docs/install-notes.txt 
